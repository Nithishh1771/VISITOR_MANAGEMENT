# Property Truth — Technical & Business Feasibility Report

*"Helping buyers discover the difference between what was promised, what was documented, and what actually exists."*

---

## Executive Summary

Property Truth's central idea — fusing **seller claims + official documents + physical measurement** into one evidence-based report — is genuinely strong and not well served by any existing product in India. The weakest part of the concept is the **rotating ToF hardware**, which is over-engineered relative to what it delivers, is the most expensive and fragile part of the system, and is partially commoditized by phone-based AR scanning apps already on the market. The strongest, most defensible part of the concept is the **document + RERA + moisture + photo fusion engine** — that is where you should spend most of your early effort, not on custom mechanical hardware.

My core recommendation, elaborated below: **build the software/verification engine first, ship a phone-only MVP, and treat hardware as an optional accuracy add-on you introduce in v2** once you've validated that people will actually pay for the report itself.

---

## 1–2. Hardware Concept & Room-Scan Feasibility

**What's right:** Sensor fusion (ToF + IMU + camera) instead of trusting raw ToF distance is the correct instinct — "largest distance ≠ room dimension" is exactly the right skepticism to have.

**What's weak, and why:**

1. **A single rotating point-ToF sensor is the wrong sensor choice.** A point ToF (e.g. VL53L1X) gives you one distance per angle step — a 1D radial "slice" of the room. To disambiguate furniture from walls you're forced to rely almost entirely on the smartphone camera, which means the ToF data alone is not self-sufficient. A **multi-zone ToF sensor** such as ST's VL53L5CX/L7CX/L8CX gives an 8×8 grid of distances per position (up to ~4 m range in good conditions, useful range closer to 1.7–2.8 m under normal indoor lighting) instead of one point. That single grid tells you, in one shot, whether what's in front of the sensor is a flat wall (uniform distances across the grid), a doorway (a sudden jump in a sub-region of the grid), or furniture (an irregular, non-planar cluster of distances). This is a materially better sensor for the same rotating-mount idea, and it reduces how much you need to lean on camera-based furniture classification.
2. **IMU-based angle tracking will drift and is not trustworthy for azimuth.** A cheap 6-axis IMU (accelerometer + gyro) can tell you tilt (pitch/roll) reliably, but integrating gyro data to track *rotation angle* (yaw) drifts steadily — over one full 360° sweep you could accumulate several degrees of error, which directly corrupts your room-dimension math. Two fixes: (a) drive the rotation with a **stepper motor** and count steps (open-loop but far more reliable than gyro integration for known, discrete positions), ideally cross-checked with (b) a cheap magnetic rotary encoder (e.g. AS5600) for closed-loop confirmation. Don't rely on the IMU for azimuth — only for confirming the device is level.
3. **A continuously-rotating design forces a slip ring or wireless link across the rotating joint**, adding mechanical cost and failure points. A simpler, cheaper, more robust design: **limit rotation to a single ±175° sweep** (not full continuous 360°) using a geared DC motor or hobby servo with a wider-than-standard range, so wiring can flex back and forth without a slip ring. Combined with the device being placed roughly centrally, a 350° sweep captures effectively the same room coverage as a full rotation.
4. **The "largest distance ≠ wall" instinct is correct, and there's a real algorithmic trick for it**: for a straight wall, as a sensor at a fixed point rotates through angle θ, the measured distance to that wall follows a **secant curve**, d(θ) = d₀ / cos(θ − θ₀), where d₀ is the perpendicular distance to the wall and θ₀ is the angle at which the sensor points directly at the wall. Furniture, doorways, and openings break this curve (their distance profile doesn't fit a secant). Fitting short angular windows of your scan data to secant curves (essentially a RANSAC-style line-fitting problem in polar coordinates) is a much more principled way to separate "wall" from "everything else" than thresholding on raw distance, and it's the kind of thing a final-year CSE/IT project can actually implement and defend in a viva.

**Is one rotating (multi-zone) ToF + IMU + smartphone camera technically feasible for room measurement?** Yes, for **rectangular-ish, moderately furnished rooms**, to roughly ±3–8% dimensional accuracy — good enough to catch a builder claiming 11×10 ft when the room is actually 9×8 ft, which is the real-world use case that matters. It is **not** feasible to reliably reconstruct L-shaped rooms, rooms with glass walls/mirrors (ToF lasers pass through or bounce unpredictably off glass and highly reflective/dark surfaces), or heavily cluttered rooms without asking the user to reposition the device — and your app should say so honestly rather than silently producing a confident-looking wrong number.

**Difficult-scenario behavior (recommended):**

| Scenario | System behavior |
|---|---|
| Sofa/bed partially blocking a wall | Use the secant-fit + camera segmentation to extrapolate the wall line behind the furniture; flag as "estimated," not "measured" |
| Open doorway / corridor | Detect the distance discontinuity, camera confirms an opening, exclude that angular window from room-boundary fitting |
| L-shaped / irregular room | Explicitly unsupported for full auto-scan in v1; prompt user to scan each rectangular sub-section separately |
| Glass wall / mirror / dark or reflective surface | ToF returns unreliable or missing readings; flag "low confidence," ask for a second scan position or manual measurement |
| Very small room (< 2 m across) | Near-field ToF minimum range (~2 cm) is fine, but reflections/multipath near corners hurt accuracy — average multiple readings |
| Very large room / hall | Beyond ~4 m the sensor's usable range drops sharply in bright light — recommend a two-position scan and stitch |

---

## 3. Smartphone Role

Correct architecture. One addition worth taking seriously: **modern smartphone AR frameworks (ARCore on Android, ARKit/LiDAR on newer iPhones) can already do monocular or LiDAR-assisted room measurement on their own**, with typical real-world accuracy in the same ballpark (a few percent) as your proposed hardware for open, well-lit rooms. This isn't a reason to abandon the hardware — phone AR still struggles with reflective/dark surfaces and can't do moisture sensing — but it means your camera-side pipeline should be built as if it will eventually *replace* the ToF for baseline dimension estimates in good conditions, with the ToF acting as a **cross-check and fallback for poor lighting or reflective materials**, not as the sole source of truth. This reframing also substantially de-risks your MVP (see Section 17).

For crack/paint/dampness visual classification: use general-purpose multimodal AI vision (see Section 11) rather than building custom-trained CV models from scratch — you don't have the labeled dataset a custom model needs, and a modern vision-capable LLM can do zero-shot "does this look like a crack / peeling paint / possible dampness stain" classification at reasonable accuracy for an MVP.

---

## 4–5. Document & RERA Verification

The area-definition distinction (carpet vs. built-up vs. super built-up) is the single most valuable, most underserved feature in this whole product — Indian buyers are chronically confused by this and it's a pure software feature with **zero hardware dependency**. Prioritize it.

**RERA reality check (researched):** There is no single, stable, public API for real-time RERA data. <cite index="21-1">The Real Estate (Regulation and Development) Act of 2016 required every Indian state to set up its own RERA authority, resulting in roughly 32 separate portals across 28 states and 8 union territories, each with its own data structure and schema.</cite> A **Unified/Central RERA portal** has been introduced to give buyers one place to search across states, <cite index="20-1">integrating multiple state RERA websites under one platform so buyers can access project, developer, and compliance information from a single system</cite> — but this is a search/discovery convenience layer, not a documented public API for bulk automated data extraction, and third-party aggregators still describe building compliance datasets via **per-state crawling**, not an official feed. <cite index="23-1">State portals let a user verify a project's registration number and expiry date, check that sanctioned plans match what's marketed, and confirm quarterly progress reports and financial disclosures are current</cite> — but this is manual, per-project lookup, not something you can legally batch-scrape at scale without risking Terms-of-Service violations.

**Conclusion: your proposed manual workflow (user enters RERA number → redirected to official portal → downloads documents → uploads to your app → AI extracts and compares) is the legally safest and most realistic approach for an early-stage product**, and I'd keep it that way rather than building scrapers. Automated official API access may become available later as the unified portal matures — treat it as a future integration, not an MVP dependency.

---

## 6. Amenity Verification

Sound as designed. The "observed / not observed" framing (rather than "exists / doesn't exist") is the legally correct way to phrase this and you should keep that discipline throughout the whole report, not just this section.

---

## 7–8. Promise-vs-Reality Engine & Final Report

The four-way classification (Verified / Difference / Unverified / Potential Issue) plus category-level confidence scores instead of one safety score is well-designed — it matches how professional inspection reports are actually written and avoids the liability of a single misleading number. Keep this structure; it's a genuine strength of the concept and worth building the whole UI around.

---

## 9. Hardware Architecture

| Component | Role | Recommended part | Why |
|---|---|---|---|
| MCU | Sensor orchestration, BLE | ESP32-S3 (WROOM-1 module) | Dual-core, built-in BLE 5, enough RAM for basic on-device buffering, cheap in India |
| Distance sensing | Multi-zone room mapping | ST VL53L5CX (or VL53L7CX for wider FoV) | <cite index="2-1">Accurate, up to 60 Hz sampling, 2 cm–4 m range, 8×8 zone array</cite> — see Section 1 for why multi-zone beats point ToF |
| Rotation | Sweep the ToF across the room | Small stepper (28BYJ-48 for v1, NEMA-11 + driver for v2) + AS5600 magnetic encoder for position confirmation | Predictable, repeatable angle steps; avoid relying on IMU yaw (see Section 1) |
| Orientation | Level/tilt detection only | BNO055 or MPU6050 | Use for pitch/roll (is the device sitting flat), not for azimuth tracking |
| Moisture | Non-invasive wall check | Capacitive/RF pinless sensing front-end (custom analog front-end — see caveat below) | Non-destructive, works on someone else's finished property (see Section 2 rationale) |
| Power | Portability | 18650 Li-ion, 2000–3000 mAh, protection circuit | Full inspection (~30–45 min) plus margin |
| Comms | Phone link | BLE (on ESP32-S3) | Already planned; correct choice, no changes needed |

**Important caveat on the moisture sensor:** off-the-shelf pinless wall-moisture *modules* (as a raw component you can just wire to the ESP32) are not a commodity part the way a ToF or IMU breakout is. <cite index="14-1">Pinless meters work by sending electromagnetic waves into the material and measuring how moisture changes the wave's speed and strength</cite> — this requires a proper capacitance/RF analog front-end circuit, not a simple digital sensor module. Budget real analog-electronics R&D time for this, or start v1 with a licensed/adapted design from an open reference circuit rather than assuming it's a plug-and-play part like the ToF sensor. This is one of the two biggest technical risk items in the whole project (see Section 17).

Also worth noting honestly: <cite index="18-1">moisture meters on walls are inherently comparative instruments rather than absolute ones — a pinless meter's readings are affected by wall thickness, embedded studs, and surface finish, so results should be compared across similar sections of the same wall rather than read as an absolute moisture percentage</cite>, and <cite index="18-1">high ambient humidity can itself reduce pinless reading accuracy by a few percentage points</cite>. Your app copy already handles this well ("possible anomaly, further inspection recommended") — keep that hedge, because the sensor genuinely cannot do better than that.

**Rotating mechanism comparison:**

| Option | Cost | Precision | Notes |
|---|---|---|---|
| Continuous-rotation servo | Low | Poor (no absolute position without extra encoder) | Not recommended alone |
| Standard hobby servo (180°) | Low | Good, but limited sweep | Fine only if combined with device rotation, adds complexity |
| Stepper (28BYJ-48) | Very low | Good (open-loop steps), slow | Best for a low-cost v1 prototype |
| Stepper (NEMA-11/17) + driver | Medium | Very good, faster | Best for v2 / production |
| DC gear motor + magnetic encoder (AS5600) | Medium | Very good, fast | Good alternative if speed matters more than stepper's inherent slowness |

**Recommendation:** 28BYJ-48 stepper for the first prototype (cheap, easy to source, "good enough" precision), single ±175° sweep (no slip ring), migrate to NEMA-11 + AS5600 encoder for a production-intent unit.

**Enclosure/size:** target a puck roughly 90–110 mm diameter × 60–80 mm tall, IP54-ish (dust/splash resistant — this is being used on floors and near bathrooms, not submerged), 3D-printed PETG or ABS for prototypes, weight under 300 g so it's easy to carry room to room.

---

## 10. Cost Analysis (₹, approximate — India, single-unit prototyping prices, mid-2026)

These are engineering estimates based on typical component pricing patterns, not live vendor quotes — validate against current Robu/Robocraze/Mouser/Digikey pricing before committing.

| Build stage | Approx. cost (₹) | Notes |
|---|---|---|
| **Prototype 1** (fixed ToF, no rotation) | 3,000 – 5,000 | ESP32-S3 dev board (~400–600), VL53L5CX breakout (~1,500–2,500 after import/GST — no local Indian distributor stock is common for ST's newest ToF parts), IMU (~150–1,000 depending on MPU6050 vs BNO055), battery + misc (~800) |
| **Prototype 2** (+ rotation mechanism) | 4,500 – 7,500 | Adds stepper + driver (~150–400), AS5600 encoder (~150–250), mechanical hardware/3D-printed mount (~500–1,000) |
| **Moisture add-on** | +1,500 – 4,000 | Highly variable — depends entirely on whether you build a custom analog front-end (cheaper in BOM, expensive in engineering time) or adapt/license an existing pinless-sensor circuit |
| **Engineering prototype** (custom PCB + optimized enclosure) | 8,000 – 18,000 **per unit**, plus one-time NRE (PCB design, tooling, testing) of roughly ₹50,000 – 1,50,000 | Small-run PCB fab (JLCPCB/local) + SLA/CNC enclosure |
| **Small batch (100–500 units)** | 2,800 – 4,500 landed cost per unit | Bulk component pricing helps; enclosure via low-volume injection or vacuum forming (~₹400–800/unit) unless you avoid mold tooling by staying with 3D printing a bit longer |
| **Mass production (1,000+ units)** | 1,800 – 3,200 per unit | Requires injection-mold tooling (₹3–10 lakh one-time), full compliance certification, and real supply-chain negotiation — this is a different company stage, not a next step |

**Certification note:** any Bluetooth-radiating consumer electronics product sold in India needs **BIS (Bureau of Indian Standards) registration** under the Compulsory Registration Scheme, and the wireless module needs to already carry **WPC/ETA approval** (most commercial BLE modules do, but a custom ESP32 design still needs the end product certified). Budget realistically for this at the small-batch stage — it's a real cost and timeline item people underestimate, not a rubber stamp.

**Software/cloud:** near-zero at student-project scale (Supabase free tier, a few dollars/month of AI API usage for document OCR/vision calls). This is genuinely the cheapest part of the whole system to prototype — another argument for starting there.

---

## 11. Software Blueprint

**Mobile app:** **Flutter.** Single codebase for Android + iOS, mature BLE plugin ecosystem (`flutter_blue_plus`), solid camera/file-upload support, and reasonable bridges to ARCore/ARKit if you add phone-based AR measurement later (Section 3). React Native is a viable alternative but BLE reliability and native AR bridging tend to be more painful in practice.

**Backend:** FastAPI (Python) — good fit for AI orchestration (calling vision/OCR models, running your wall-fitting algorithm server-side or on-device), REST for CRUD, WebSockets only if you want live scan-progress updates pushed to the app (nice-to-have, not essential for v1).

**Database:** PostgreSQL (Supabase is a reasonable managed option, and keeps you on infrastructure you already have experience with from other projects). Core schema, at a conceptual level:

```
users(id, name, email, role)
properties(id, owner_user_id, address, rera_number, listing_url)
documents(id, property_id, type, file_url, ocr_status)
claims(id, property_id, source_document_id, field_name, claimed_value, unit)
rooms(id, property_id, name, room_type)
room_scans(id, room_id, timestamp, confidence_score, raw_data_ref)
sensor_readings(id, room_scan_id, angle, zone_grid_json, distance_m)
moisture_readings(id, property_id, location_label, reading_value, classification)
images(id, property_id, room_id, file_url, ai_tags_json, timestamp, gps)
amenities(id, property_id, name, claimed, observed_bool, evidence_image_id)
inspection_reports(id, property_id, generated_at, status)
report_findings(id, report_id, category, claim_id, evidence_refs, classification, confidence)
```

**AI layer — the realistic version:**

- **OCR/document extraction:** use a modern multimodal LLM API directly on document images/PDFs rather than a separate OCR pipeline + rules engine — this dramatically cuts MVP build time, since these models can read floor plans, brochures, and sale deeds and extract structured fields (carpet area, RERA number, bedroom count, etc.) in one call with reasonable accuracy, especially if you give it a strict JSON schema to fill in.
- **Visual anomaly flagging (cracks, damp stains, unauthorized modification hints):** same approach — zero-shot vision-LLM classification for v1, rather than training a custom CNN from scratch (you don't have the labeled dataset that requires, and it's not where your differentiation lives).
- **Claim comparison / promise-vs-reality logic:** this is standard business logic, not "AI" in the ML sense — deterministic rules comparing extracted claim values against measured/observed values, with the confidence-scoring you already designed in Section 7. Keep this part rule-based and auditable; don't outsource the actual verdict-making to an LLM, since a wrong "Verified" label has real legal/trust consequences.
- **AI property assistant (chat-style Q&A over the report):** a straightforward retrieval-augmented layer on top of the structured report data — genuinely a "nice to have for v2," not core to the value proposition.

---

## 12. Room Measurement Algorithm

1. **Placement & leveling** — user places device; onboard IMU confirms tilt is within tolerance (reject scan / prompt re-placement if not level).
2. **Sweep** — stepper drives the multi-zone ToF through a ±175° sweep in fixed angular increments (e.g. every 5–7.5°, tunable), pausing briefly at each step for a stable multi-zone reading.
3. **Per-step capture** — record the full 8×8 (or configured) zone grid, the commanded step angle, and a smartphone camera frame time-synced to that step.
4. **Furniture/wall pre-classification per zone-grid** — a flat, planar, low-variance zone-grid reading at a given angle = candidate wall; high-variance/irregular grid = candidate furniture/object. Cross-check against the camera frame (simple object detection or vision-LLM tag: "sofa," "bed," "wall," "doorway").
5. **Secant-curve fitting** — within each angular window classified as "candidate wall," fit d(θ) = d₀/cos(θ−θ₀); windows that fit well (low residual) are accepted as real wall segments; windows that don't fit are treated as unreliable/furniture-obstructed and excluded or flagged for extrapolation.
6. **Outlier removal** — discard readings inconsistent with neighboring angles beyond a set threshold (handles noise, reflective-surface glitches, multipath).
7. **Boundary/polygon assembly** — stitch accepted wall segments into a closed polygon; where a segment is missing (furniture-blocked), extrapolate using the two adjacent accepted segments' geometry, and mark that portion of the polygon as "estimated" rather than "measured."
8. **Dimension calculation** — derive room length/width (or area, for irregular shapes) from the fitted polygon.
9. **Confidence scoring** — a simple composite: (% of the angular sweep covered by directly-measured, well-fitting wall segments) weighted against (how much of the remainder had to be extrapolated). Below a threshold, prompt the user to reposition rather than silently reporting a number — exactly the UX you originally proposed, now with a concrete formula behind it.

This is implementable as a final-year-project-scale system. The genuinely hard parts to be upfront about: L-shaped/irregular rooms (explicitly out of scope for full auto-scan in v1, per Section 1), and reflective/glass surfaces (flag low confidence, don't guess).

---

## 13. Critical Technical Validation

**Direct answers to your questions:**

- **Is one rotating ToF sufficient?** A rotating *point* ToF: no, too weak on its own. A rotating *multi-zone* ToF: yes, sufficient for rectangular/moderately-furnished rooms to the accuracy home buyers actually need (catching a materially wrong room size, not survey-grade precision).
- **Should smartphone AR be added?** Yes — and it should arguably be the *primary* dimension source in good lighting, with ToF as fallback/cross-check (see Section 3). This also lets you ship a hardware-free MVP.
- **Is LiDAR necessary?** No — the VL53L5CX/L7CX family *is* a (short-range) LiDAR-class multi-zone ToF sensor; you don't need a separate, more expensive automotive/robotics-grade LiDAR unit.
- **Would multiple fixed ToF sensors be better than one rotating one?** For full 360° coverage without moving parts, you'd need 6–8 fixed multi-zone sensors around the puck's circumference — this removes mechanical wear/complexity but multiplies sensor cost roughly 6–8×. Not worth it at your price point; one rotating multi-zone sensor is the better cost/complexity tradeoff.
- **Is the rotating mechanism worth the added complexity?** Marginally yes, but simplify it (single-sweep, stepper, no slip ring) rather than building a continuously-rotating gimbal.

**Architecture comparison:**

| | A: 1 fixed point-ToF | B: 2 fixed angled point-ToF | C: 1 rotating point-ToF | D: 1 rotating point-ToF + phone AR | E: multiple ToF + phone AI | **F (recommended): 1 rotating multi-zone ToF + phone AR, phone-AR-primary** |
|---|---|---|---|---|---|---|
| Cost | Lowest | Low | Low-medium | Medium | Highest | Medium |
| Accuracy | Poor | Poor-fair | Fair | Good | Very good | Good-very good |
| Mechanical complexity | None | None | Medium | Medium | Low (no motor) but 6-8x sensors | Medium (simplified single-sweep) |
| Furniture handling | Very poor | Poor | Poor (needs heavy camera reliance) | Fair-good | Good | Good (multi-zone self-disambiguates) |
| Full-room mapping | No | Limited | Yes (slow) | Yes | Yes (fast) | Yes |
| Battery use | Low | Low | Medium | Medium | Medium-high | Medium |
| Commercial viability | Low (too weak to trust) | Low | Medium | Good | Good but expensive to manufacture | **Best balance for an early-stage Indian hardware startup** |

---

## 14. Business Model

**Be realistic about who buys this and how often.** An individual home buyer needs this product perhaps once every several years — that's a terrible fit for a hardware-purchase or subscription model aimed at consumers directly (high customer acquisition cost, near-zero repeat usage). The more monetizable early customers are people who need this **repeatedly**:

- Independent property inspectors / inspection agencies (tool + report-generation SaaS)
- Real estate agencies wanting to differentiate listings with a trust badge
- Banks/NBFCs verifying collateral before disbursing a home loan
- Resale/rental platforms wanting verified-condition listings

**Recommended early model: "Inspection-as-a-service" via a small network of trained inspectors who carry the device, not "sell hardware to every buyer."** Buyer pays per-report (₹1,500–4,000 range is a plausible early anchor, adjust after real willingness-to-pay research); you keep the hardware fleet small and centrally maintained; software/SaaS layer is what actually scales. Once demand and unit economics are proven, expand into B2B SaaS licensing for inspection agencies/banks, and only then consider hardware-as-a-product for individual buyers.

---

## 15. Competitive Advantage

Be honest about where the real moat is: it is **not** the ToF hardware (increasingly commoditized by phone-based AR measurement apps and standalone laser distance meters/moisture meters that already exist and are individually cheap). The real, defensible USP is:

1. The **fusion engine** — nobody else combines seller claims + official documents + RERA cross-check + physical measurement + moisture + amenity verification into one evidence-classified report.
2. **Neutral, buyer-side positioning** — professional inspectors and most real-estate platforms have a structural or financial relationship with sellers/builders; a product explicitly built for and paid by the *buyer* is a genuine trust differentiator in the Indian market where this kind of independent verification is rare.
3. **India-specific document/RERA literacy** baked into the product (area-definition clarity, state-portal navigation help) — something generic AR-measurement apps don't attempt at all.

---

## 16. Legal & Ethical Considerations

- **Access/consent:** scanning, photographing, and moisture-testing a property that isn't yet owned by the buyer requires the current owner's or occupant's permission — build explicit consent capture into the inspection workflow (who authorized this visit, when) as a first-class report field, not an afterthought.
- **RERA/document data:** stick to the user-initiated download-and-upload workflow (Section 4–5); avoid automated scraping of state portals, which sits in legally grey territory relative to each portal's terms of use.
- **Liability and disclaimers:** every report must clearly and repeatedly state that it does **not** replace a licensed structural engineer, surveyor, or lawyer, and should not be the sole basis for a legal dispute — this needs to be actual legal-reviewed language before commercial launch, not just app copy you wrote yourself.
- **False positives/negatives:** the "possible anomaly, further inspection recommended" hedge you've already built in throughout the spec is the right posture — keep it consistent everywhere, especially in the moisture and crack-detection findings, where overclaiming could cause real financial harm if someone walks away from a fine property or, worse, proceeds with a purchase because your system missed something.
- **Data retention/privacy:** you'll be storing photos and floor-plan-level detail of private residences and PII from official documents (owner names, ID numbers on sale deeds) — this needs a real data-retention and access-control policy from day one, not just at scale.

---

## 17. Final Recommendation

1. **Best hardware architecture:** Option F — one rotating **multi-zone** ToF (VL53L5CX-class) on a simplified single-sweep (no slip ring) mount, stepper-driven with encoder position confirmation, paired with phone-AR as the primary/cross-check dimension source, plus a pinless moisture front-end as a separate handheld mode.
2. **Components to prototype with:** ESP32-S3, VL53L5CX, 28BYJ-48 stepper + ULN2003 driver, BNO055 (tilt only), Li-ion battery — build the moisture sensing as a clearly separate, later work-package given its analog-design difficulty.
3. **Approximate prototype cost:** ₹3,000–7,500 for Prototype 1/2 as scoped in Section 10; treat moisture add-on and enclosure/PCB polishing as separate budget lines.
4. **Best software stack:** Flutter (app) + FastAPI (backend) + PostgreSQL/Supabase (data) + multimodal-LLM-based document/vision AI (see Section 11) rather than custom-trained CV models for v1.
5. **Room-scanning algorithm:** secant-curve wall fitting + multi-zone furniture disambiguation + confidence-gated user prompts, as detailed in Section 12.
6. **Moisture method:** non-contact/pinless — the only ethical/practical option on a property you don't own — with comparative, not absolute, reporting language.
7. **AI architecture:** vision-LLM-first for OCR and visual anomaly flagging; deterministic, auditable rules engine for the actual promise-vs-reality verdicts.
8. **Database architecture:** as sketched in Section 11 — relational, evidence-linked (every finding traceable to its source claim + supporting sensor/photo evidence).
9. **User journey:** register property → upload documents (auto-extract claims) → enter RERA number (manual download/upload flow) → book/perform inspection (photos + optional device scan + moisture spot-checks + amenity photos) → auto-generated report with confidence scores and buyer questions.
10. **MVP features:** document upload + OCR claim extraction + area-definition clarity tool + manual RERA cross-check workflow + phone-camera visual checklist with AI-assisted crack/damp flagging + basic promise-vs-reality report. **No custom hardware required for the MVP.**
11. **Postpone:** the rotating ToF device entirely, custom-trained CV models, automated RERA API integration, B2B bank/insurer integrations.
12. **Biggest technical risks:** (a) the moisture-sensing analog front-end is genuinely hard EE work, not an off-the-shelf integration; (b) angular/dimensional accuracy is easy to overstate and easy for a skeptical user to disprove with a tape measure; (c) document OCR accuracy on non-standardized, sometimes scanned/handwritten Indian builder paperwork.
13. **Biggest business risks:** (a) individual buyers are low-frequency customers — a hardware-first, direct-to-consumer model has weak unit economics; (b) liability exposure if a report is wrong and someone relies on it for a major financial decision; (c) capital requirements for certification and small-batch manufacturing are a real jump from student-project scale.
14. **6-month roadmap:** Months 1–2: software MVP (document upload, OCR extraction, area-definition tool, manual RERA workflow). Months 3–4: phone-camera visual checklist + AI flagging, first-pass report generator with confidence scoring. Months 5–6: pilot with a handful of real properties/inspectors, gather willingness-to-pay data, begin ToF hardware prototyping in parallel as a side track (not gating the software launch).
15. **1-year roadmap:** Quarter 3: refine report/report-trust based on pilot feedback, formalize inspector-network or B2B(agency/bank) pilot. Quarter 4: working hardware Prototype 2 (rotating multi-zone ToF) tested against phone-AR baseline; decide, with real data, whether hardware materially improves report accuracy/trust enough to justify manufacturing investment.
16. **Realistic viability assessment:** As a **software-first verification and reporting service**, this is a credible, buildable, differentiated Indian real-estate-tech business with a real problem behind it and no direct incumbent doing exactly this. As a **custom-hardware-first company**, it's a much harder, more capital-intensive path competing partly against free/cheap phone-based measurement tools, with genuine hardware-engineering risk concentrated in the moisture sensor. **The path most likely to succeed is to prove the verification engine and business model first, in software, and let real pilot data — not the original spec — decide whether the hardware is worth building at all.**
