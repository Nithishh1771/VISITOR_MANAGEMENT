from flask import Flask, render_template, request
import json
import os

app = Flask(__name__)

DATA_FILE = "data.json"


# Create data.json if it doesn't exist
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w") as file:
        json.dump([], file)


# Home page
@app.route("/")
def home():
    return render_template("index.html")


# Handle form submission
@app.route("/submit", methods=["POST"])
def submit():

    # Get data from HTML form
    name = request.form.get("name")
    age = request.form.get("age")
    email = request.form.get("email")
    phone = request.form.get("phone")
    gender = request.form.get("gender")
    department = request.form.get("department")
    address = request.form.get("address")

    # Store in dictionary
    student = {
        "name": name,
        "age": age,
        "email": email,
        "phone": phone,
        "gender": gender,
        "department": department,
        "address": address
    }

    # Read existing data
    with open(DATA_FILE, "r") as file:
        data = json.load(file)

    # Add new student
    data.append(student)

    # Save back to JSON
    with open(DATA_FILE, "w") as file:
        json.dump(data, file, indent=4)

    # Show success page
    return render_template("success.html", name=name)


if __name__ == "__main__":
    app.run(debug=True)